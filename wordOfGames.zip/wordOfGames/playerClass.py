
class player:

    def __init__(self, name):
        self.name = name


    def hello(self):
       print(f"Hello {self.name} and welcome to the World of Games (WoG).Here you can find many cool games to play.")


